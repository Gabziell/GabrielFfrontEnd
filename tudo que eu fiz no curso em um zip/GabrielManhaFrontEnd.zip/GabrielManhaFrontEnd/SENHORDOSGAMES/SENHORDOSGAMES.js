const meuBotao = document.getElementById("meuBotao")
const meuBotao2 = document.getElementById("meuBotao2")
const meuBotao3 = document.getElementById("meuBotao3")
const meuBotao4 = document.getElementById("meuBotao4")
function redirecionar() {

 window.location.href = "https://uudt-ma.github.io/img/regra/regra5.jpg"
}

meuBotao.addEventListener("click", redirecionar)
meuBotao2.addEventListener("click", redirecionar)
meuBotao3.addEventListener("click", redirecionar)
meuBotao4.addEventListener("click", redirecionar)