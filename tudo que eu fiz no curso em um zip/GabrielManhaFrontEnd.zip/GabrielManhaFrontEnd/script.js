const meuBotao = document.getElementById("meuBotao")

function redirecionar() {

 window.location.href = "https://www.gifcen.com/wp-content/uploads/2022/01/meme-gif-3.gif"
}

meuBotao.addEventListener("click", redirecionar)







