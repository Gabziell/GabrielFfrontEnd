const tripulacao = prompt ("insira a sua tripulação")

