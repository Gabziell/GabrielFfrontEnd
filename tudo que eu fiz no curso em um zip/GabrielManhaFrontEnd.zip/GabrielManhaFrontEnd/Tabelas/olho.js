/*
const anoDeNascimento = 2008
const anoAtual = 2023
let idade = anoAtual - anoDeNascimento

console.log (idade)
*/

