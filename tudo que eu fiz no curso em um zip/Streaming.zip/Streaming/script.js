
const meuBotao = document.getElementById("meuBotao")
function redirecionar() {

 window.location.href = "https://uudt-ma.github.io/img/regra/regra5.jpg"
}

meuBotao.addEventListener("click", redirecionar)
